<?php
Define("KEYONE","NEpfSjaHtFD1BgCTrDQkune4/rUkOuwP8zElOIcp3Vo=");
Define("KEYTWO","K2BlqR2D/rKyZZtVHben2DPid5Bua9IntX8tgD7eWmXjSrLYuhXRlNaUQ7MjRVYrlCOdbujjl9K25hBEKHG2Lw==");

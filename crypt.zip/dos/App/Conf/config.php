<?php
//Je definis ici les constante contenant les informations de connexion à ma base de données
Define("USER", "root");
Define("PASSWORD", "");
Define("HOST", "localhost");
Define("DB", "basequo");

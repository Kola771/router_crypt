<?php
require_once("../App/Controllers/crypt.php");
class Home {
    use Crypt;
    public function viewHome()
    {
        require_once("../App/Views/home.phtml");
    }
    public function viewLogin()
    {
        require_once("../App/Views/login.phtml");
    }
}
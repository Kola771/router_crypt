
<?php
if(!empty($_POST['tims'])){
    $result=date('d/m/Y',$_POST['tims']);
    echo $result;
}
?>
<form method="post">
    <input type="text" name="tims">
    <input type="submit" value="valider">
</form>

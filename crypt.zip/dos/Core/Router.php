<?php
require_once ("../App/Conf/key.php");

class Router
{
    public function autoload($classname)
    {
        return spl_autoload_register(
            function ($classname) {
                $root = "../App/Controllers/";
                $file = $root . $classname . ".php";
                if (is_readable($file)) {
                    require("../App/Controllers/" . $classname . ".php");
                } else {
                    require("../App/Views/error/404.phtml");
                    exit();
                }
            }
        );
    }
    
    public function datadecrypt($input)
    {
        $input = str_replace('[plus]', '+', $input);
        $first_key = base64_decode(KEYONE);
        $second_key = base64_decode(KEYTWO);
        $mix = base64_decode($input);

        $method = "aes-256-cbc";
        $iv_length = openssl_cipher_iv_length($method);

        $iv = substr($mix, 0, $iv_length);
        $first_encrypted = substr($mix, $iv_length);

        $data = openssl_decrypt($first_encrypted, $method, $first_key, OPENSSL_RAW_DATA, $iv);
        return $data;
    }

    public function convertToPascalCase($url) {
        return preg_replace("/-/", "", ucwords($url, "-"));
    }

    public function convertToCamelCase($url) {
        return lcfirst($this->convertToPascalCase($url));
    }

    public function dispatch()
    {
        $url = $_SERVER["QUERY_STRING"];
        if (isset($_GET['goto'])) {
            $controller = $this->datadecrypt($_GET['goto']);
            $controller = $this->convertToPascalCase($controller);
            if($this->autoload($controller)) {
                $controller_object = new $controller();
                if(isset($_GET["action"]))
                {
                    $action = $this->datadecrypt($_GET["action"]);
                    $action = $this->convertToCamelCase($action);
                    
                    if(method_exists($controller, $action)) {
                            $controller_object->$action();
                    } else {
                       echo "La page que vous recherchez n'existe pas. Veuillez revoir le chemin que vous avez entré:";
                       exit();
                    }
                } else {
                    require("../App/Views/error/404.phtml");
                    exit();
                }
                
            } else {
                require("../App/Views/error/404.phtml");
                exit();
            }
        }


        if (isset($_GET['ajax'])) {
        }


        if ($url === "") {
            $controller = "Home";
            $action = "viewHome";
            if($this->autoload($controller)) {
                $controller_object = new $controller();
                $controller_object->$action();
            }
        }
    }
}

